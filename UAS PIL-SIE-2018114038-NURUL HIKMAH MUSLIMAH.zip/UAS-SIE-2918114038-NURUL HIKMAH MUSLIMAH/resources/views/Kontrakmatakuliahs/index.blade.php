@extends('layout.app')

@section('title', 'Kontrakmatakuliahs')
@section('content')
<a href="/kontrakmatakuliahs/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Kontrak Matakuliah</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Mahasiswa ID</th>
      <th scope="col">Semester ID</th>
      
    </tr>
  </thead>
  <tbody>
  @foreach ($kontrakmatakuliahs as $kontrakmatakuliah)
    <tr>
    <td>{{$kontrakmatakuliah->mahasiswa_id}}</td>
    <td>{!!$kontrakmatakuliah->semester_id !!}</td>
    

    <td><a href="/kontrakmatakuliahs/{{$kontrakmatakuliah->id}}/edit"><button type="button" class="btn btn-outline-secondary">Edit</a></button></td>
    <form action="/kontrakmatakuliahs/{{$kontrakmatakuliah->id}}" method="POST">
    @csrf
    @method('DELETE')
    <td><button class="btn btn-outline-secondary">Delete</button></td>
    </form>
    </tr>
    @endforeach
  </tbody>
</table>
<div>
    {{ $kontrakmatakuliahs -> links() }}
    </div>
@endsection