@extends('layout.app')

@section('title', 'semesters')
@section('content')
<a href="/semesters/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Semester</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Semester</th>
      
    </tr>
  </thead>
  <tbody>
  @foreach ($semesters as $semester)
    <tr>
    <td>{{$semester->semester}}</td>
    
    <td><a href="/semesters/{{$semester->id}}/edit"><button type="button" class="btn btn-outline-secondary">Edit</a></button></td>
    <form action="/semesters/{{$semester->id}}" method="POST">
    @csrf
    @method('DELETE')
    <td><button class="btn btn-outline-secondary">Delete</button></td>
    </form>
    </tr>
    @endforeach
  </tbody>
</table>
<div>
    {{ $semesters -> links() }}
    </div>
@endsection