<?php

namespace App\Http\Controllers;
use App\Models\Kontrakmatakuliahs;
use Illuminate\Http\Request;

class KontrakmatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kontrakmatakuliahs = Kontrakmatakuliahs::orderBy('id','desc')->paginate(3);
        return view('kontrakmatakuliahs.index', compact('kontrakmatakuliahs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kontrakmatakuliahs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
        'mahasiswa_id' => 'required',
        'semester_id' => 'required',
        
        ]);

        $kontrakmatakuliahs = new kontrakmatakuliahs;

        $kontrakmatakuliahs->mahasiswa_id = $request->mahasiswa_id;
        $kontrakmatakuliahs->semester_id = $request->semester_id;
       
       
        $kontrakmatakuliahs->save();
        return redirect('/kontrakmatakuliahs');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Kontrakmatakuliah = Kontrakmatakuliahs::where('id', $id)->first();
        return view('kontrakmatakuliahs.show' ,['kontrakmatakuliah' => $Kontrakmatakuliah]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Kontrakmatakuliah = Kontrakmatakuliahs::where('id', $id)->first();
        return view('kontrakmatakuliahs.edit' , ['kontrakmatakuliah' => $Kontrakmatakuliah]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
        'mahasiswa_id' => 'required',
        'semester_id' => 'required',
        
        ]);
            Kontrakmatakuliahs::find($id)->update([
            'mahasiswa_id' => $request->mahasiswa_id,
            'semester_id' => $request->semester_id,
            
            ]);
            
            return redirect('/kontrakmatakuliahs');
    }
    public function destroy($id)
    {
        Kontrakmatakuliahs::find($id)->delete();
        return redirect('/kontrakmatakuliahs');
    }
}