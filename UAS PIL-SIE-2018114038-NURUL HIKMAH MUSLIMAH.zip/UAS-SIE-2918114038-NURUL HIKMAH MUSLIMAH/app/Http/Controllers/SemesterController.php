<?php

namespace App\Http\Controllers;
use App\Models\Semesters;
use Illuminate\Http\Request;

class SemesterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $semesters = Semesters::orderBy('id','desc')->paginate(3);
        return view('semesters.index', compact('semesters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('semesters.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $request->validate([
            'semester' => 'required',
            
            ]);
        $semesters = new semesters;

        $semesters->semester = $request->semester;
       
       
        $semesters->save();
        return redirect('/semesters');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Semester = Semesters::where('id', $id)->first();
        return view('semesters.show' ,['semester' => $Semester]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Semester = Semesters::where('id', $id)->first();
        return view('semesters.edit' , ['semester' => $Semester]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
        'semester' => 'required',
        
        ]);
            Semesters::find($id)->update([
            'semester' => $request->semester,
            
            ]);
            
            return redirect('/semesters');
    }
    public function destroy($id)
    {
        Semesters::find($id)->delete();
        return redirect('/semesters');
    }
}