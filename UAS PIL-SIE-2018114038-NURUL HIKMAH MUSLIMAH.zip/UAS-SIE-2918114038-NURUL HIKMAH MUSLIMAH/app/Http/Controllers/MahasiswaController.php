<?php

namespace App\Http\Controllers;
use App\Models\Mahasiswas;
use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mahasiswas = Mahasiswas::orderBy('id','desc')->paginate(3);
        return view('mahasiswas.index', compact('mahasiswas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mahasiswas = new mahasiswas;

        $mahasiswas->nama_mahasiswa = $request->nama_mahasiswa;
        $mahasiswas->alamat = $request->alamat;
        $mahasiswas->no_tlp = $request->no_tlp;
        $mahasiswas->email = $request->email;
       
        $mahasiswas->save();
        return redirect('/mahasiswas');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {    
        $Mahasiswa = Mahasiswas::where('id', $id)->first();
        return view('mahasiswas.edit' , ['mahasiswa' => $Mahasiswa]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
        'nama_mahasiswa' => 'required',
        'alamat' => 'required',
        'no_tlp' => 'required',
        'email' => 'required'
        ]);
            Mahasiswas::find($id)->update([
            'nama_mahasiswa' => $request->nama_mahasiswa,
            'alamat' => $request->alamat,
            'no_tlp' => $request->no_tlp,
            'email' => $request->email
            ]);
            
            return redirect('/mahasiswas');
    }
    public function destroy($id)
    {
       //
    }
}