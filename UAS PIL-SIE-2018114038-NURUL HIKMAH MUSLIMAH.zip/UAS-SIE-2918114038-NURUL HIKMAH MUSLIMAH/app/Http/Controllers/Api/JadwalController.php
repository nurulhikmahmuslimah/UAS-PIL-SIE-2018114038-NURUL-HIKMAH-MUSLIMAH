<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json([
            'success'   => true,
            'message'   => 'Data jadwalsi',
            'data'      => $jadwal
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'jadwal' => 'required',
            'matakuliah_id' => 'required',
        ]);

        $jadwal = Jadwal::create([
            'jadwal'  => $request->jadwal,
            'matakuliah_id' => $request->matakuliah_id,
        ]);

        if($jadwal){
            return response()->json([
                'success'   => true,
                'message'   => 'Berhasil',
                'data'      => $jadwal
            ], 200);
            
        } else {
            return response()->json([
                'success'   => false,
                'message'   => 'Gagal',
                'data'      => $jadwal
            ], 409);
    }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $jadwal = Jadwals::where('id', $id)->first();

        return response()->json([
            'success' => true,
            'message' => 'Detail jadwalsi',
            'data' => $jadwal
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'jadwal' => 'required',
            'matakuliah_id' => 'required'
        ]);

        $jadwal = Jadwals::find($id)->update([
            'jadwal' => $request->nama_jadwal,
            'matakuliah_id' => $request->matakuliah_id
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cek = $jadwal::find($id)->delete();
        return response()->json([
            'success' => true,
            'message' => 'Post Updated',
            'data' => $cek
        ], 200);
    }
}
