<?php $__env->startSection('title', 'Kontrakmatakuliahs'); ?>
<?php $__env->startSection('content'); ?>
<a href="/kontrakmatakuliahs/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Kontrak Matakuliah</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Mahasiswa ID</th>
      <th scope="col">Semester ID</th>
      
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $kontrakmatakuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontrakmatakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($kontrakmatakuliah->mahasiswa_id); ?></td>
    <td><?php echo $kontrakmatakuliah->semester_id; ?></td>
    

    <td><a href="/kontrakmatakuliahs/<?php echo e($kontrakmatakuliah->id); ?>/edit"><button type="button" class="btn btn-outline-secondary">Edit</a></button></td>
    <form action="/kontrakmatakuliahs/<?php echo e($kontrakmatakuliah->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <td><button class="btn btn-outline-secondary">Delete</button></td>
    </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<div>
    <?php echo e($kontrakmatakuliahs -> links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensimahasiswa\resources\views/kontrakmatakuliahs/index.blade.php ENDPATH**/ ?>