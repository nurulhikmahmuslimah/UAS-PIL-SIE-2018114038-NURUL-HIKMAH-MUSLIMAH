<?php $__env->startSection('title', 'Jadwals'); ?>
<?php $__env->startSection('content'); ?>
<a href="/jadwals/create" type="button" class="btn btn-secondary mb-2 btn-sm">jadwal</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Jadwal</th>
      <th scope="col">Matakuliah ID</th>
      
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($jadwal->jadwal); ?></td>
    <td><?php echo e($jadwal->matakuliah_id); ?></td>

    <td><a href="/jadwals/<?php echo e($jadwal->id); ?>/edit"><button type="button" class="btn btn-outline-secondary">Edit</a></button></td>
    <form action="/jadwals/<?php echo e($jadwal->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <td><button class="btn btn-outline-secondary">Delete</button></td>
    </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<div>
    <?php echo e($jadwals -> links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oooo\resources\views/jadwals/index.blade.php ENDPATH**/ ?>